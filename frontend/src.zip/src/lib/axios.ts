export { API_BASE_URL } from '@/lib/api/client'
export { apiClient as default } from '@/lib/api/client'

import type { PayrollRecord as PayrollRecordBase } from "@/types/hrm"

export type PayrollRecord = PayrollRecordBase

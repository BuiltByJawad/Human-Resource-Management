import api, { API_BASE_URL } from '@/lib/axios'

export { API_BASE_URL }
export default api

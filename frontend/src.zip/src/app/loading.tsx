'use client'

// Disable the global route-level loader to avoid flashes on sidebar navigation.
export default function Loading() {
    return null
}

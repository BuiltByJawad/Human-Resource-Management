
export * from './dto';
export * from './training.repository';
export * from './training.service';
export * from './training.controller';
import trainingRoutes from './training.routes';
export { trainingRoutes };


export * from './dto';
export * from './goals.repository';
export * from './goals.service';
export * from './goals.controller';
import goalsRoutes from './goals.routes';
export { goalsRoutes };

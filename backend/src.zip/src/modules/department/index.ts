export * from './department.controller';
export * from './department.service';
export * from './department.repository';
export * from './dto';
export { default as departmentRoutes } from './department.routes';

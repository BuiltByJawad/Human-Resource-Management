export interface CreateOrganizationDto {
    name?: string;
    description?: string;
    settings?: any;
}

export interface UpdateOrganizationDto {
    name?: string;
    description?: string;
    settings?: any;
}

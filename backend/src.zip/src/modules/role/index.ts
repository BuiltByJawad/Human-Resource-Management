export * from './role.controller';
export * from './role.service';
export * from './role.repository';
export * from './dto';
export { default as roleRoutes } from './role.routes';

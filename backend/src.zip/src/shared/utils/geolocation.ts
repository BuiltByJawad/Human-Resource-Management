/**
 * Calculates the distance between two points on Earth using the Haversine formula
 * @param lat1 Latitude of point 1
 * @param lon1 Longitude of point 1
 * @param lat2 Latitude of point 2
 * @param lon2 Longitude of point 2
 * @returns Distance in meters
 */
export const calculateDistance = (
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
): number => {
    const R = 6371e3 // Earth's radius in meters
    const φ1 = (lat1 * Math.PI) / 180
    const φ2 = (lat2 * Math.PI) / 180
    const Δφ = ((lat2 - lat1) * Math.PI) / 180
    const Δλ = ((lon2 - lon1) * Math.PI) / 180

    const a =
        Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
        Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

    return R * c
}

/**
 * Validates if a user is within the allowed radius of the office
 * @param userLat User's latitude
 * @param userLon User's longitude
 * @param officeLat Office latitude
 * @param officeLon Office longitude
 * @param maxDistanceMeters Maximum allowed distance in meters
 * @returns Object containing isValid boolean and actual distance
 */
export const validateLocation = (
    userLat: number,
    userLon: number,
    officeLat: number,
    officeLon: number,
    maxDistanceMeters: number
): { isValid: boolean; distance: number } => {
    const distance = calculateDistance(userLat, userLon, officeLat, officeLon)
    return {
        isValid: distance <= maxDistanceMeters,
        distance: Math.round(distance), // Round to nearest meter
    }
}
